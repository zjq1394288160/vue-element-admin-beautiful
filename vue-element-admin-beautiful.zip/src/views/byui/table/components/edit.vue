<template>
  <el-dialog
    :title="title"
    :visible.sync="dialogFormVisible"
    @close="close"
    width="500px"
  >
    <el-form :model="form" label-width="80px">
      <el-form-item label="标题">
        <el-input v-model="form.title" autocomplete="off"></el-input>
      </el-form-item>
      <el-form-item label="作者">
        <el-input v-model="form.author" autocomplete="off"></el-input>
      </el-form-item>
      <el-form-item label="点击量">
        <el-input v-model="form.pageviews" autocomplete="off"></el-input>
      </el-form-item>
      <el-form-item label="状态">
        <el-input v-model="form.status" autocomplete="off"></el-input>
      </el-form-item>
      <el-form-item label="日期">
        <el-date-picker
          v-model="form.display_time"
          placeholder="选择日期"
          type="date"
        ></el-date-picker>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="close">取 消</el-button>
      <el-button type="primary" @click="save">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
export default {
  name: "TableEdit",
  data() {
    return {
      form: {
        name: "",
        region: "",
        date1: "",
        date2: "",
        delivery: false,
        type: [],
        resource: "",
        desc: "",
      },
      title: "",
      dialogFormVisible: false,
    };
  },
  created() {},
  methods: {
    showEdit(row) {
      if (!row) {
        this.title = "增加";
      } else {
        this.title = "编辑";
        this.form = row;
      }
      this.dialogFormVisible = true;
    },
    close() {
      this.form = this.$options.data().form;
      this.dialogFormVisible = false;
    },
    save() {
      this.form = this.$options.data().form;
      this.dialogFormVisible = false;
    },
  },
};
</script>

<style lang="scss" scoped></style>
