import Vue from "vue";
import byuiIcon from "zx-icon";

Vue.component("byui-icon", byuiIcon);
