import { heading, img, keel, text } from "zx-keel";

const byuiKeel = keel;
const byuiKeelHeading = heading;
const byuiKeelImg = img;
const byuiKeelText = text;
export { byuiKeel, byuiKeelHeading, byuiKeelImg, byuiKeelText };
