const form = {
  state: {
    srcCode: "",
  },
  mutations: {
    SET_SRC_TABLE_CODE(state, srcCode) {
      state.srcCode = srcCode;
    },
  },
};

export default form;
