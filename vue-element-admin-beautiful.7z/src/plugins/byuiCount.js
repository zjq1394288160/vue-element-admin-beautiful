import byuiCount from "zx-count";

export default byuiCount;
